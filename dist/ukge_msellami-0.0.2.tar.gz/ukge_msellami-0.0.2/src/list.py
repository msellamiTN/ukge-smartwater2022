"""
List of models
"""

from enum import Enum

class ModelList(Enum):
    LOGI = "logi"
    RECT = "rect"